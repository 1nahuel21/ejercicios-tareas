let factorial = 1;
let num = 10;
while (num>1) {
    
    factorial *= num;
    num--
}
console.log(factorial)