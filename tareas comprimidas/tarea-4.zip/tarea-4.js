let Nombre = "Nahuel";
let Apellido = "Cellone";
let estudiante = Nombre.concat(" ").concat(Apellido);
let estudianteMayus = estudiante.toUpperCase();
let estudianteMinus = estudiante.toLowerCase();
let cantidadDeLetras = estudiante.length;
let primeraLetraNombre = Nombre.substring(0, 1);
let finalLetraApellido = Apellido.substring(Apellido.length - 1, Apellido.length);
let estudianteSinEspacios = estudiante.replace(/ /g, "");
let booleano = estudiante.includes(Nombre);
console.log(booleano)
