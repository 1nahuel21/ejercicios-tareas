//este es el mensaje de bienvenida 

console.log("Esta es la puerta de entrada al proyecto")

//este es el mensaje de despedida 
console.log("adios")