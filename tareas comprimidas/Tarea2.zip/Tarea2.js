const Lista = [
    "Nahuel",
    21,
    true,
    new Date(2000, 11, 24),
    Libro = {
        titulo : "mushoku tensei",
        autor : "Rifujin na Magonote",
        fecha : new Date(2012, 11, 22),
        url : "https://novelasligeras.net/index.php/producto/mushoku-tensei-isekai-ittara-honki-dasu-novela-web/",
    }
]