let factorial = 1 ;
for (let i = 10; i > 0 ; i--) {
    factorial = factorial * i ;
}
console.log(factorial)